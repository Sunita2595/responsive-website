(window.tawkJsonp = window.tawkJsonp || []).push([
    ["chunk-2d0b9454"], {
        "31dd": function(a, t, s) {
            "use strict";
            var e = {
                    name: "base-header"
                },
                d = s("2877"),
                n = Object(d.a)(e, (function(a, t) {
                    var s = t._c;
                    return s("div", t._g(t._b({
                        class: ["tawk-card tawk-card-primary tawk-card-small tawk-header-container tawk-flex-none tawk-header tawk-custom-color", t.data.class, t.data.staticClass],
                        style: [t.data.staticStyle, t.data.style]
                    }, "div", t.data.attrs, !1), t.listeners), [s("div", {
                        staticClass: "tawk-text-center"
                    }, [t._t("default")], 2)])
                }), [], !0, null, null, null);
            t.a = n.exports
        }
    }
]);