/* ========== owlSlider js Strat ========== */
$(window).load(function() {
    $('#slider').nivoSlider();
});

/* ========== Carousel js Strat ========== */

/* ========== Carousel js End ========== */
/* ========== Accodin js Strat ========== */
/**
 *	@name							Accordion
 *	@descripton						This Jquery plugin makes creating accordions pain free
 *	@version						1.3
 *	@requires						Jquery 1.2.6+
 *
 *	@author							Jan Jarfalk
 *	@author-email					jan.jarfalk@unwrongest.com
 *	@author-website					http://www.unwrongest.com
 *
 *	@licens							MIT License - http://www.opensource.org/licenses/mit-license.php
 */

(function(jQuery) {
    jQuery.fn.extend({
        accordion: function() {
            return this.each(function() {

                var $ul = $(this);

                if ($ul.data('accordiated'))
                    return false;

                $.each($ul.find('ul, li>div'), function() {
                    $(this).data('accordiated', true);
                    $(this).hide();
                });

                $.each($ul.find('a'), function() {
                    $(this).click(function(e) {
                        activate(this);
                        return void(0);
                    });
                });
                var sPath = window.location.pathname;
                var sPage = sPath.substring(sPath.lastIndexOf('/') + 1);
                var findvar = 'http://' + window.location.host + window.location.pathname.substring(0, sPath.lastIndexOf('/') + 1) + sPage;


                //alert($(this).find('a[href='+findvar+']')[0]);
                var active = (findvar) ? $(this).find('a[href="' + findvar + '"]')[0] : '';
                if (active) {
                    activate(active, 'toggle');
                    $(active).parents().show();
                }

                function activate(el, effect) {
                    $(el).parent('li').toggleClass('active').siblings().removeClass('active').children('ul, div').slideUp('fast');
                    $(el).siblings('ul, div')[(effect || 'slideToggle')]((!effect) ? 'fast' : null);
                }

            });
        }
    });
})(jQuery);

<!-- *********** Product Detial page js Strat *********** --> 
$(document).ready(function() {
    $(".img1").elevateZoom({
        gallery: 'gallery_01',
        cursor: 'pointer',
        galleryActiveClass: "active"
    });
});

$(function() {
    SyntaxHighlighter.all();
});
$(window).load(function() {
    $('#carousel').flexslider({
        animation: "slide",
        controlNav: false,
        directionNav: true,
        animationLoop: false,
        slideshow: false,
        itemWidth: 123,
        itemMargin: 10,
        autoplay: false,
        asNavFor: '#slider'
    });

    $('#slider').flexslider({
        animation: "fade",
        controlNav: false,
        directionNav: true,
        animationLoop: false,
        slideshow: false,
        sync: "#carousel",
        start: function(slider) {
            $('body').removeClass('loading');
        }
    });
});
<!-- ***********  Product Detial page js End *********** -->	
/* ========== Accodin js End ========== */
/* ========== Owl Carasol js Strat ========== */
$('#owl-example').owlCarousel({
    loop: true,
    dots: false,
    margin: 10,
    responsiveClass: true,
    nav: true,
    responsive: {
        0: {
            items: 1,

        },
        600: {
            items: 3,
        },
        768: {
            items: 4,
        },
        1000: {
            items: 3,

        }
    }
});
$('#owl-news').owlCarousel({
    loop: true,
    dots: false,
    margin: 20,
    responsiveClass: true,
    nav: true,
    autoplay: true,
    autoplayTimeout: 5000,
    autoplayHoverPause: true,
    responsive: {
        0: {
            items: 1,

        },
        600: {
            items: 1,
        },
        600: {
            items: 1,
        },
        1000: {
            items: 1,

        }
    }
});
/* ========== Owl Carasol js End ========== */


/* ========== Select Dropdown js Strat ========== */
$(".myval").select2({
    width: "100%",
    dropdownAutoWidth: true,
});
/* ========== Select Dropdown js End ========== */
/* ========== Bootstrap Gallery js Strat ========== */
$('#borderless-checkbox').on('change', function() {
    var borderless = $(this).is(':checked');
    $('#blueimp-gallery').data('useBootstrapModal', !borderless);
    $('#blueimp-gallery').toggleClass('blueimp-gallery-controls', borderless);
});
/* ========== Bootstrap Gallery js End ========== */
/* ========== Bootstrap Carousel js Strat ========== */
$('.carousel').carousel({
    pause: true,
    interval: false
})
/* ========== Bootstrap Carousel js End ========== */
/* ========== Perfect-Scrollbar js Strat ========== */
$(document).ready(function($) {
    $('.description').perfectScrollbar({
        wheelSpeed: 20,
        wheelPropagation: false
    });
});
/* ========== Perfect-Scrollbar js End ========== */
/* ========== News (jquery.bootstrap.newsbox) js Strat ========== */
$(function() {
    $(".demo1").bootstrapNews({
        newsPerPage: 3,
        autoplay: true,
        pauseOnHover: true,
        direction: 'up',
        navigation: false,
        newsTickerInterval: 4000,
        onToDo: function() {
            //console.log(this);
        }
    });
});
/* ========== News (jquery.bootstrap.newsbox) js End ========== */
(function($) {
    $(function() {
        $(".scroller").simplyScroll({
            orientation: 'vertical',
            customClass: 'vert'
        });
    });
})(jQuery);
/* ========== Back to top js Strat ========== */
$(function() {
    $(window).scroll(function() {
        if ($(this).scrollTop() != 0) {
            $('#toTop').fadeIn();
        } else {
            $('#toTop').fadeOut();
        }
    });

    $('#toTop').click(function() {
        $('body,html').animate({
            scrollTop: 0
        }, 800);
    });
});
/* ========== Back to top js End ========== */
/* ========== Form js Strat ========== */
$(document).on('change', '.btn-file :file', function() {
    var input = $(this),
        numFiles = input.get(0).files ? input.get(0).files.length : 1,
        label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
    input.trigger('fileselect', [numFiles, label]);
});

$(document).ready(function() {
    $('.btn-file :file').on('fileselect', function(event, numFiles, label) {

        var input = $(this).parents('.input-group').find(':text'),
            log = numFiles > 1 ? numFiles + ' files selected' : label;

        if (input.length) {
            input.val(log);
        } else {
            if (log) alert(log);
        }

    });
});
$(function() {
    $.placeholder.shim();
});
if (Function('/*@cc_on return 8===document.documentMode@*/')()) {
    document.documentElement.className = 'ie8';
}
if (Function('/*@cc_on return 9===document.documentMode@*/')()) {
    document.documentElement.className = 'ie9';
}
/* ========== Form js End ========== */